function [mask] = segmentation(left,right)
  % Add function description here
  %
  %


end
