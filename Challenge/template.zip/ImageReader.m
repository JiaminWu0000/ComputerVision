classdef ImageReader
  % Add class description here
  %
  %

end
