function [result] = render(frame,mask,bg,mode)
  % Add function description here
  %
  %

end
