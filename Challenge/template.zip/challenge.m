%% Computer Vision Challenge 2020 challenge.m

%% Start timer here


%% Generate Movie

while loop ~= 1
  % Get next image tensors

  % Generate binary mask

  % Render new frame
end

%% Stop timer here
elapsed_time = 0;


%% Write Movie to Disk
if store
  %v = VideoWriter(dst,'Motion JPEG AVI');
end
